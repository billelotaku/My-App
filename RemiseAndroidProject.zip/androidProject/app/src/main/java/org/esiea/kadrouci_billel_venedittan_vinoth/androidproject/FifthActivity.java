package org.esiea.kadrouci_billel_venedittan_vinoth.androidproject;

import android.app.Activity;
import android.content.Intent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by billelotaku on 12/12/2016.
 */

public class FifthActivity extends Activity {

    /*
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        setTitle("CONTACTS");

        final RecyclerView rv = (RecyclerView) findViewById(R.id.list);

        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new MyAdapter());

    }
    */

    ListView liste = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        liste = (ListView) findViewById(R.id.list);
        List<String> exemple = new ArrayList<String>();
        exemple.add("KADROUCI Billel");
        exemple.add("VENEDITTAN Vinoth");
        exemple.add("KHALIFA Ali");
        exemple.add("BAKWA Mathias");
        exemple.add("MONTIGNY Alexandre");
        exemple.add("DEMITURK Tarikakan");
        exemple.add("ROUVIER Frédéric");
        exemple.add("MAILLOT Daniel");
        exemple.add("ALOUETTE BROU");
        exemple.add("OU YANG Yvon");
        exemple.add("JI Pei");
        exemple.add("MESBAH Yanis");
        exemple.add("SEGOVIA MERA Daniel");
        exemple.add("DAHOU Sofian");
        exemple.add("FERREOL Tom");
        exemple.add("LE HOLLOCO Jean-Antoine");
        exemple.add("PERRAULT William");
        exemple.add("OUMOURI ASSOUMANI Darui Dine");
        exemple.add("KPAKPABIA Rodrigue");
        exemple.add("GENEVE Guillaume");
        exemple.add("COSTA Thomas");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, exemple);
        liste.setAdapter(adapter);
    }

}
