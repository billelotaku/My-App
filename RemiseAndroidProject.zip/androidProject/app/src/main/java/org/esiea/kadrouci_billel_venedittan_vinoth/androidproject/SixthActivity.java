package org.esiea.kadrouci_billel_venedittan_vinoth.androidproject;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by billelotaku on 13/12/2016.
 */

public class SixthActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sixth);
        setTitle("PROJET ANDROID");

    }

}
