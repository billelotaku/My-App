package org.esiea.kadrouci_billel_venedittan_vinoth.androidproject;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by billelotaku on 14/12/2016.
 */

public class SecondActivity extends AppCompatActivity {

    private RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        IntentFilter inf = new IntentFilter(BIERS_UPDATE);
        LocalBroadcastManager.getInstance(this).registerReceiver(new BierUpdate(),inf);

        rv = (RecyclerView) findViewById(R.id.rv_biere);
        rv.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        DonneesBieres biereData[] = {};
        rv.setAdapter(new BiersAdapter(biereData));

    }

    public JSONArray getBiersFromFile(){

        try{
            InputStream is = new FileInputStream(getCacheDir()+"/" + "bieres.json");
            byte[] buffer = new byte [is.available()];
            is.read(buffer);
            is.close();
            return new JSONArray(new String(buffer, "UTF-8")); //Le tableau
        }catch(IOException e){
            e.printStackTrace();
            return new JSONArray();
        }catch (JSONException e) {
            e.printStackTrace();
            return new JSONArray();
        }
    }

    private class BiersAdapter extends RecyclerView.Adapter< BiersAdapter.BierHolder>{

        private DonneesBieres[] biersList;

        public BiersAdapter(DonneesBieres[] biersList){
            this.biersList = biersList;
        }
        @Override
        public BiersAdapter.BierHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout, null);
            BierHolder bh = new BierHolder(itemLayoutView);
            return bh;
        }

        @Override
        public void onBindViewHolder( BiersAdapter.BierHolder holder, int position) {
            // Log.i("tag","coucou");
            JSONArray bieres = getBiersFromFile();
            try{

                JSONObject jo = bieres.getJSONObject(position);
                holder.modifierItemList(jo.getString("name"));
                holder.modifierItemAnnee(jo.getString("description"));
            }catch(JSONException e){
                e.printStackTrace();
            }
        }

        public void setNewBiere(JSONArray ja){

            notifyDataSetChanged();
        }

        @Override
        public int getItemCount() {
            return getBiersFromFile().length();
        }

        public class BierHolder extends RecyclerView.ViewHolder {
            private TextView itemView;
            private TextView itemViewAnnee;

            public BierHolder(View itemView) {
                super(itemView);
                this.itemView = (TextView) itemView.findViewById(R.id.item_title);
                this.itemViewAnnee = (TextView) itemView.findViewById(R.id.item_plus);
            }
            public void modifierItemAnnee(String s) {
                itemViewAnnee.setText(s);
            }
            public void modifierItemList(String s) {
                itemView.setText(s);
            }
        }
    }

    public static final String BIERS_UPDATE = "com.octip.cours.inf4042_11.BIERS_UPDATE";
    public class BierUpdate extends BroadcastReceiver {
        public void onReceive(Context c, Intent i){
            Log.d(" ... ",i.getAction());
            BiersAdapter s = (BiersAdapter) rv.getAdapter();
            s.setNewBiere(getBiersFromFile());
            Toast.makeText(getApplicationContext(),"Telechargement en cours",Toast.LENGTH_LONG).show();
        }
    }
}
