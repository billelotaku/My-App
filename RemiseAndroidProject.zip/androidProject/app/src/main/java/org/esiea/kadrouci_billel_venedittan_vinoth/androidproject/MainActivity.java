package org.esiea.kadrouci_billel_venedittan_vinoth.androidproject;

import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.GridLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.RelativeLayout;

import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("PROJET ANDROID");

        TextView texte = (TextView) findViewById(R.id.le_texte);
        texte.setText("App made by Billel and Vinoth");

        RecyclerView rv = (RecyclerView) findViewById(R.id.rv_biere);
        rv.setLayoutManager(new LinearLayoutManager(this, GridLayout.HORIZONTAL, false));


        Button b = (Button) findViewById(R.id.button);
        b.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                Intent second = new Intent(getApplicationContext(), FifthActivity.class);
                startActivity(second);
            }
        });

        Button b1 = (Button) findViewById(R.id.button7);
        b1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                Intent fifth = new Intent(getApplicationContext(), SixthActivity.class);
                startActivity(fifth);
            }
        });

        Button b2 = (Button) findViewById(R.id.button6);
        b2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                notif_test();
            }
        });

        Button b3 = (Button) findViewById(R.id.button5);
        b3.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                Intent start = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(start);
            }
        });

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.plus:
                notif_test();
                return true;
            case R.id.download:
                GetBiersService.startActionBiere(this);
                Toast.makeText(getApplicationContext(), "Telechargement en cours", Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void notif_test() {
        NotificationCompat.Builder xBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.ichigo)
                        .setContentTitle("Notification")
                        .setContentText("Ceci est une notification :)");

        NotificationManager NotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationManager.notify(0, xBuilder.build());

    }

    public class BierUpdate extends BroadcastReceiver {
        public void onReceive(Context c, Intent i) {
            Log.d(" ... ", i.getAction());
            Toast.makeText(getApplicationContext(), "Telechargement en cours", Toast.LENGTH_LONG).show();
        }
    }

}

