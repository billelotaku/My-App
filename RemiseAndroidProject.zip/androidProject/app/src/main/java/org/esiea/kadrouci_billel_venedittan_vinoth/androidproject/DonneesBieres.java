package org.esiea.kadrouci_billel_venedittan_vinoth.androidproject;

/**
 * Created by billelotaku on 13/12/2016.
 */

public class DonneesBieres {

    private String nom;
    private String detail;

    public DonneesBieres(String nom, String detail){
        this.nom = nom;
        this.nom = nom;
    }

    public String getTitle() {
        return this.nom;
    }

    public void setTitle(String title) {
        this.nom = title;
    }

    public String getDetail() {
        return this.detail;
    }

    public void setDetail( String detail) {
        this.detail = detail;
    }

}
